package com.employee.details.proto;


import org.apache.kafka.common.serialization.Deserializer;
import com.google.protobuf.InvalidProtocolBufferException;
import com.employee.details.proto.EmployeeDetailBean.EmployeeDetails;

public class EmployeeDetailsBeanDeserializer extends Adapter implements Deserializer<EmployeeDetails> {

	@Override
	/*
	 * To deserilise   the Informations Which is been serilised while pushing into kafka 
	*/
	public EmployeeDetails deserialize(String topic, byte[] detailsArray) {
		System.out.println("Entered Deserilisation class ");
		EmployeeDetails message = null;
		try{
		message =  EmployeeDetails.parseFrom(detailsArray);	
		System.err.println("Deserilisation done successfully "+message );
		} catch (InvalidProtocolBufferException e) {
			e.printStackTrace();
		}finally{
			detailsArray=null;
			topic=null;
		}
		return message;
	}

	
}