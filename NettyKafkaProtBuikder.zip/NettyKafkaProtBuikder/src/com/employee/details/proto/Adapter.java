package com.employee.details.proto;

import java.util.Map;

import com.employee.details.proto.EmployeeDetailBean.EmployeeDetails;


public class Adapter {
	public void close() {}
    public void configure(Map<String,?> configs, boolean isKey) {}
	public byte[] serialize(String topic, EmployeeDetails detailsBean) {
		// TODO Auto-generated method stub
		return null;
	}
	public EmployeeDetails deserialize(String topic, byte[] detailsArray) {
		// TODO Auto-generated method stub
		return null;
	}
}